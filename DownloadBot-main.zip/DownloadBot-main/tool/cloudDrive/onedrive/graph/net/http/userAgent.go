package http

func getUserAgent() string {
	return "PostmanRuntime/7.26.3"
}
